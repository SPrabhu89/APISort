﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Maersk.Sorting.Api.Repository
{
   public interface IDBRepo
    {
        Task SaveToDB(SortJob job);
        Task<SortJob> GetSpecficJob(string id);
        Task<List<SortJob>> GetAllSortedJobs();
    }
}
