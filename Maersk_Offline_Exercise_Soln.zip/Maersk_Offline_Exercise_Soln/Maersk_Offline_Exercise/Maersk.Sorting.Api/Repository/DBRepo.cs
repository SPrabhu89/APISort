﻿using Maersk.Sorting.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Maersk.Sorting.Api.Repository
{
    public class DBRepo : IDBRepo
    {
        public ApplicationDBContext _dbContext;

        public DBRepo(ApplicationDBContext _dbContext)
        {
            this._dbContext = _dbContext;
        }

        //Pagination Can be implemented to display specfic set of records
        public async Task<List<SortJob>> GetAllSortedJobs()
        {
            List<SortJob> listOfSortedJobs = new List<SortJob>();
            var allSortedJobs = _dbContext.SortJobs.ToList();
            foreach (var sortJob in allSortedJobs)
            {
                listOfSortedJobs.Add(MapDBSortWithSortModel(sortJob));
            }
            return await Task.FromResult(listOfSortedJobs);
        }

        public async Task<SortJob> GetSpecficJob(string id)
        {
            JobEntityModel jobEntity = _dbContext.SortJobs.FirstOrDefault(x => x.Id == id);
            SortJob sortJob = MapDBSortWithSortModel(jobEntity);

            return await Task.FromResult(sortJob);
        }

        public Task SaveToDB(SortJob sortedJob)
        {
            //Find if sortedJob ID already exist
            var sortedJobs = _dbContext.SortJobs.ToList().Find(x => x.Id == sortedJob.Id.ToString());
            if (sortedJobs != null)
            {
                sortedJobs.Id = sortedJob.Id.ToString();
                sortedJobs.Status = sortedJob.Status.ToString();
                sortedJobs.Duration = sortedJob.Duration.HasValue ? (TimeSpan)sortedJob.Duration : TimeSpan.Parse("1.00:00:00");
                sortedJobs.Input = string.Join(',', sortedJob.Input);
                sortedJobs.Output = sortedJob.Output != null ? string.Join(',', sortedJob.Output) : "";


                _dbContext.SortJobs.Update(sortedJobs);
            }
            // Else Add new jobs
            else
            {
                JobEntityModel sortJobEntity = new JobEntityModel(sortedJob);
                _dbContext.Add(sortJobEntity);
            }
            _dbContext.SaveChanges();
            return Task.CompletedTask;
        }

        private static SortJob MapDBSortWithSortModel(JobEntityModel model)
        {
            SortJob sortedJob;
            if(model==null)
            {
                return null!;
            }
           
                Guid jobId = new Guid(model.Id);
                SortJobStatus status = default!;

                if (model.Status == "Completed")
                    status = SortJobStatus.Completed;
                else
                    status = SortJobStatus.Pending;

                TimeSpan duration = model.Duration;

                int[] input = Array.ConvertAll(model.Input.Split(','),value=> Convert.ToInt32(value));
                int[]? output = default!;
                if (!String.IsNullOrEmpty(model.Output))
                    output = Array.ConvertAll(model.Output.Split(','), value => Convert.ToInt32(value));
                else
                    output = null;

                sortedJob = new SortJob(jobId, status, duration, input, output);
           
            return sortedJob;
        }
    }
}
