USE [master]
GO

/****** Object:  Table [dbo].[SortJobs]    Script Date: 22-12-2021 12:40:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SortJobs](
	[Id] [nvarchar](450) NOT NULL,
	[Status] [nvarchar](max) NOT NULL,
	[Duration] [time](7) NOT NULL,
	[Input] [nvarchar](max) NOT NULL,
	[Output] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_SortJobs] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


