﻿using Maersk.Sorting.Api.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Maersk.Sorting.Api.Repository
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) : base(options)
        {

        }
        //Non nullable property : must always contain a value and cannot be nil
        public DbSet<JobEntityModel> SortJobs { get; set; } =default!;
        

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Moved to appsettings.json

            //if (!optionsBuilder.IsConfigured)
            //{
            //    optionsBuilder.UseSqlServer(@"Server=DESKTOP-JUNR4RR\SQLEXPRESS;Database=master;Trusted_Connection=True;");
            //}
        }
    }
}
