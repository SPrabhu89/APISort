﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Maersk.Sorting.Api.LoggerService;
using Maersk.Sorting.Api.Services;
using System.Net;

namespace Maersk.Sorting.Api.Controllers
{
    [ApiController]
    [Route("sort")]
    public class SortController : ControllerBase
    {
        private readonly ISortJobProcessor _sortJobProcessor;
        private readonly ILoggerManager _loggerManager;
        public SortController(ISortJobProcessor sortJobProcessor,ILoggerManager loggerManager)
        {
            _sortJobProcessor = sortJobProcessor;
            _loggerManager = loggerManager;
        }

        [HttpPost("run")]
        [Obsolete("This executes the sort job asynchronously. Use the asynchronous 'EnqueueJob' instead.")]
        public async Task<ActionResult<SortJob>> EnqueueAndRunJob(int[] values)
        {
           //_loggerManager.LogInfo($"Background Job pending sort jobs : {allPendingSortJobs.Count}");
            var pendingJob = new SortJob(
                id: Guid.NewGuid(),
                status: SortJobStatus.Pending,
                duration: null,
                input: values,
                output: null);

            var completedJob = await _sortJobProcessor.Process(pendingJob);

            return Ok(completedJob);
        }

        [HttpPost]
        public async Task<ActionResult<SortJob>> EnqueueJob(int[] values)
        {
            // TODO: Should enqueue a job to be processed in the background.
            try
            {
                _loggerManager.LogInfo($"Background Job pending sort jobs to Process Asynchronously");
                var processJob = new SortJob(
                  id: Guid.NewGuid(),
                  status: SortJobStatus.Pending,
                  duration: null,
                  input: values,
                  output: null);

                await _sortJobProcessor.ProcessJobsAsync(processJob);
                _loggerManager.LogInfo($"Process Completed on executing pending jobs");
                return Ok(processJob);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet]
        public async Task<ActionResult<SortJob[]>> GetJobs()
        {
            // TODO: Should return all jobs that have been enqueued (both pending and completed).
            try
            {
                _loggerManager.LogInfo($"Fetch All Jobs");
                SortJob[] allJobs = await _sortJobProcessor.GetSortedJobsAsync();
                _loggerManager.LogInfo($"Process Completed on Retrieving all jobs");
                return Ok(allJobs);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet("{jobId}")]
        public async Task<ActionResult<SortJob>> GetJob(Guid jobId)
        {
            // TODO: Should return a specific job by ID.
            try
            {
                _loggerManager.LogInfo($"Fetch Jobs for Requested sort job id : {jobId}");
                SortJob sortJob = await _sortJobProcessor.GetSpecificJobAsync(jobId.ToString());
                _loggerManager.LogInfo($"Process Completed on Retrieving requested job");
                return Ok(sortJob);
            }

            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
