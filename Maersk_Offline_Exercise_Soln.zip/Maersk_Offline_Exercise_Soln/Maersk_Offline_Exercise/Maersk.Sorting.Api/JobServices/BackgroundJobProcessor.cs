﻿using Maersk.Sorting.Api.Repository;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Maersk.Sorting.Api.LoggerService;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Maersk.Sorting.Api.Services
{
    public class BackgroundJobProcessor : BackgroundService
    {
        IServiceProvider serviceProvider;
        private readonly ILoggerManager _loggerManager;

        public BackgroundJobProcessor(ILoggerManager loggerManager, IServiceProvider serviceProvider)
        {
            this._loggerManager = loggerManager;
            this.serviceProvider = serviceProvider;
        }
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                using (var scope = serviceProvider.CreateScope())
                {
                    var DBRepository = (IDBRepo)scope.ServiceProvider.GetRequiredService(typeof(IDBRepo));


                    List<SortJob> allPendingSortJobs = (await DBRepository.GetAllSortedJobs()).FindAll(x => x.Status == SortJobStatus.Pending);
                   
                    _loggerManager.LogInfo($"Background Job pending sort jobs : {allPendingSortJobs.Count}");

                    if (allPendingSortJobs.Count > 0)
                    {
                        foreach (SortJob sortJob in allPendingSortJobs)
                        {
                            _loggerManager.LogInfo($"Background Job Process for sortjob ID : {sortJob.Id}");

                            var stopwatch = Stopwatch.StartNew();
                            var output = sortJob.Input.OrderBy(n => n).ToArray();
                            var duration = stopwatch.Elapsed;

                            SortJob newSortJob = new SortJob(
                            id: sortJob.Id,
                            status: SortJobStatus.Completed,
                            duration: duration,
                            input: sortJob.Input,
                            output: output);

                            _loggerManager.LogInfo($"Process Completed for SortJob ID : {sortJob.Id}");

                            await DBRepository.SaveToDB(newSortJob);
                        }

                    }
                    else
                    {
                        _loggerManager.LogInfo($" No Pending Jobs to Process");
                    }
                }
            }
        }
    }
}
