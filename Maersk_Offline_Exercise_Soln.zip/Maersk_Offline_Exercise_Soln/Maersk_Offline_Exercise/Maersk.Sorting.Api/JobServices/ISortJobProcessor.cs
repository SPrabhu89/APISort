﻿using System.Threading.Tasks;

namespace Maersk.Sorting.Api
{
    public interface ISortJobProcessor
    {
        Task<SortJob> GetSpecificJobAsync(string id);
        Task<SortJob> Process(SortJob job);
        Task<SortJob[]> GetSortedJobsAsync();
        Task ProcessJobsAsync(SortJob job);

    }
}