﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Maersk.Sorting.Api.LoggerService;
using Maersk.Sorting.Api.Repository;

namespace Maersk.Sorting.Api
{
    public class SortJobProcessor : ISortJobProcessor
    {
        private readonly ILoggerManager _loggerManager;
        private IDBRepo _dBRepo;
       
        public SortJobProcessor(ILoggerManager loggerManager, IDBRepo dBRepo)
        {
            this._loggerManager = loggerManager;
            this._dBRepo = dBRepo;
        }

        public async Task<SortJob[]> GetSortedJobsAsync()
        {
            List<SortJob> listOfJobs = await _dBRepo.GetAllSortedJobs();

            SortJob[] arrayJobs = listOfJobs.ToArray<SortJob>();

            return arrayJobs;
        }

        public async Task<SortJob> GetSpecificJobAsync(string id)
        {
            var job =await _dBRepo.GetSpecficJob(id);

            return job;
        }

        public async Task<SortJob> Process(SortJob sortJob)
        {
            _loggerManager.LogInfo($"Sort job for ID { sortJob.Id}");

            var stopwatch = Stopwatch.StartNew();

            var output = sortJob.Input.OrderBy(n => n).ToArray();
            await Task.Delay(5000); // NOTE: This is just to simulate a more expensive operation

            var duration = stopwatch.Elapsed;

            _loggerManager.LogInfo($"Completed processing job with ID : {sortJob.Id}");

            return new SortJob(
                id: sortJob.Id,
                status: SortJobStatus.Completed,
                duration: duration,
                input: sortJob.Input,
                output: output);
        }

        public async Task ProcessJobsAsync(SortJob sortJob)
        {
            _loggerManager.LogInfo($"Save processing job with ID : {sortJob.Id}");
            await this._dBRepo.SaveToDB(sortJob);
            _loggerManager.LogInfo($"Saved job ID : {sortJob.Id} to DB");
        }
    }
}
