﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Maersk.Sorting.Api.Models
{
    public class JobEntityModel
    {
        [Required]
        public string Id { get; set; }
        [Required]
        public string Status { get; set; }
        [Required]
        public TimeSpan Duration { get; set; }
        [Required]
        public string Input { get; set; }
        public string Output { get; set; }

        // Non-nullable field must contain a non-null value when exiting constructor.
        public JobEntityModel()
        {
            Id = string.Empty;
            Status = string.Empty;
            Duration = Duration!;
            Input = string.Empty;
            Output = string.Empty;
        }

        public JobEntityModel(SortJob sortjob)
        {
            Id = sortjob.Id.ToString();
            Status = sortjob.Status.ToString();
            if(sortjob.Duration.HasValue)
            {
                Duration = (TimeSpan)sortjob.Duration;
            }

            if (!string.IsNullOrEmpty(sortjob.Input.ToString()))
            {
                Input = string.Join(',', sortjob.Input);
            }
            else
                Input = string.Empty;

            if (sortjob.Output != null)
            {
                Output = string.Join(',', sortjob.Output);
            }
            else
            {
                Output = string.Empty;
            }

        }
    }
}

